#include "kernel/types.h"
#include "user/user.h"

#define N (1024 * 1024)   // BIG array

int arr[N];

int main() {
  printf("Triggering swap...\n");

  // Fill memory → forces page allocation
  for(int i = 0; i < N; i++){
    arr[i] = i;
  }

  // Access again → forces swap-in
  for(int i = 0; i < N; i++){
    if(arr[i] != i){
      printf("ERROR at %d\n", i);
      exit(1);
    }
  }

  printf("Swap test completed\n");
  exit(0);
}