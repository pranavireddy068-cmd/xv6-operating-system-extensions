#include "kernel/types.h"
#include "user/user.h"

#define PAGES 50

int main() {
  printf("Starting swap + disk scheduling test\n");

  setdisksched(0);  // FCFS

  for(int i = 0; i < 3; i++){
    if(fork() == 0){
      printf("Child %d started\n", i);

      char *p = sbrk(PAGES * 4096);

      for(int j = 0; j < PAGES; j++){
        p[j*4096] = j;
      }

      printf("Child %d done\n", i);
      exit(0);
    }
  }

  for(int i = 0; i < 3; i++) wait(0);

  printf("Test completed\n");
  exit(0);
}