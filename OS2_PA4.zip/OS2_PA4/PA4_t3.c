#include "kernel/types.h"
#include "user/user.h"

#define PAGES 100

void run_test(int policy){
  setdisksched(policy);

  char *p = sbrk(PAGES * 4096);
  for(int i = 0; i < PAGES; i++){
    p[i*4096] = i;
  }

  printf("Policy %d done\n", policy);
}

int main(){
  run_test(0); // FCFS
  run_test(1); // SSTF
  exit(0);
}