#include "kernel/types.h"
#include "user/user.h"

int main(){
  char *p = sbrk(4096 * 10);

  for(int i = 0; i < 10; i++){
    p[i*4096] = i;
  }

  printf("RAID test done\n");
  exit(0);
}