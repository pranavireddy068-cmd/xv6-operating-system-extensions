#include "kernel/types.h"
#include "user/user.h"

#define PAGES 150

int main(){
  char *p = sbrk(PAGES * 4096);

  for(int i = 0; i < PAGES; i++){
    p[i*4096] = i % 128;
  }

  // force eviction
  for(int i = 0; i < PAGES; i++){
    char tmp = p[i*4096];
    if(tmp != i % 128){
      printf("ERROR at %d\n", i);
      exit(1);
    }
  }

  printf("Data correct after swap!\n");
  exit(0);
}