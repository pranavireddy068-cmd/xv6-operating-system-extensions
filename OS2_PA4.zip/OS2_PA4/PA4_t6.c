#include "kernel/types.h"
#include "user/user.h"

int main(){
  char *p = sbrk(4096 * 20);

  for(int i = 0; i < 20; i++){
    p[i*4096] = i;
  }

  // trigger reads again
  for(int i = 0; i < 20; i++){
    printf("%d ", p[i*4096]);
  }

  printf("\nRAID5 reconstruction test done\n");
  exit(0);
}