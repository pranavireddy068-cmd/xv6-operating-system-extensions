#ifndef DISK_H
#define DISK_H

#include "types.h"
struct proc;   
// request types
#define READ  0
#define WRITE 1

// disk request API
void submit_disk_request(int type, int swap_idx, int block_offset, void *data, struct proc *p);
void process_requests(void);

#endif